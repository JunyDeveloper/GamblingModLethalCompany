# CHANGELOG

## 1.0.9
- For the default configuration, increase double chance by 3% and decrease zero chance by 3%

## 1.0.8
- Fix gambling machining activing multiple times in one interaction

## 1.0.7
- Fix interaction key showing up incorrectly

## 1.0.6

- Changed scrap value currency dollar icon to match the ingame currency icon
- Update interaction key displayed on screen to be the user's set interaction key

## 1.0.5

- Updated readme for feature request

## 1.0.4

- Updated readme

## 1.0.3

- Configurable fields to enable music and to set music volume

## 1.0.2

- Update readme format

## 1.0.1

- Update readme

## 1.0.0

- Release
